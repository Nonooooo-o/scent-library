# Private Scent Library / 私藏香水世界

The existing perfume Site, rebuilt as an explorable personal collection. Its project identity and owner-only audience are preserved. No morning-archive project is included or modified.

## Collection and provenance

- 1,612 stable IDs, 219 brands, 127 personal five-star ratings.
- All ratings and embedded image bytes checked against both supplied Office documents.
- `data/perfumes.json` preserves the established records and historic research fields. Display descriptions are exact values from the uploaded workbook.
- `data/collection.json` is the compact presentation projection of those records. Every view uses its canonical `image` field.
- The new interface uses only `scents`, parsed literally from the workbook's `香调轮廓以…为主` wording. It does not display previous inferred fragrance fields.
- 40 unconfirmed years remain unconfirmed and are excluded from the chronological view.
- `scripts/sync-source.py WORKBOOK DOCX` regenerates both data files and the full source audit. Stable IDs are checked, not reassigned.
- Original images are retained under `public/perfumes/`. The site serves the existing, complete, uncropped WebP equivalents. Many originals are only 135 pixels tall; no fabricated high-resolution replacements are used.

## Routes

`/` explores the collection; `/archive` indexes it; `/brands` and `/brand/:slug` open shelves; `/timeline` explores decades; `/five-star` presents private ratings; `/scents` connects source scent terms; `/perfume/:id` presents records; `/search` performs instant retrieval.

Legacy hash links, `/all`, and established brand slugs remain supported. Archive filters, search, sort, view, and pagination live in the URL. Navigation records scroll positions in the current history entry. Image view transitions are progressive enhancement; reduced-motion users retain the complete interface.

## Immersive entrance prototype

This iteration changes HOME / EXPLORE only. Existing Archive, brand index, chronological index, five-star index, scent index and detail contents retain their exact prior implementation and stylesheet.

- One sticky full-viewport scene, 28 genuine cutout images, a layered 1612 monument and a native-scroll camera through projected depth. No WebGL, stock images or generated bottle replacements.
- Horizontal pointer/touch drag, quiet pointer parallax, focus/hover isolation, approach movement and native image View Transitions where available. Motion is requestAnimationFrame-driven and stops when settled or the document is hidden; no wheel interception or perpetual JS render loop.
- Brands, Timeline and 5★ transform the same scene. Shareable `/?space=brands&brand=...`, `/?space=time` and `/?space=five&bottle=...` preserve the selected destination in navigation history. These lead into the existing functional indexes/details.
- All 219 brands can be selected; time uses 17 real decade groups; the quiet chamber cycles the 127 actual five-star records. Random discovery samples the full collection without altering it.
- Mobile uses a separate two-line typographic composition, 12 objects and horizontal touch drag. Reduced motion removes camera travel/ambient drift and exposes destinations immediately. Low-performance/save-data desktop devices use 18 objects and simpler transforms.
- `data/bottle-tones.json` contains muted colors sampled from the existing images, used only for ambient lighting. It is not perfume metadata.
- `npm run test:world` checks the new projected geometry, responsive object budgets, rendered image mappings, every brand and favourite selection, and the unchanged scope of the existing tools. Run `validate:data` first to generate its shared model bundle.

## Development and validation

Run the existing npm scripts. `npm run validate:data` validates exact data preservation, search/filter/sort/pagination, actual server-rendered routes, and a reproducibly randomized 100-record image comparison across archive, brand, detail, and shelf views. `npm run test:smoke` validates the production entrypoint, all 1,612 image assets, and SPA fallback after building.

The Vite SPA is deployed as static assets, avoiding embedding every image inside a Worker. Site authentication remains controlled by Sites. The deployment manifest retains the existing project ID.

`data/validation-report.json` and `data/world-validation-report.json` record validation results and limitations. Browser preview in this execution environment was rejected by its URL security policy. Desktop and mobile CSS were reviewed; live browser, Safari, interaction, and viewport visual QA could not be completed. Do not interpret server rendering or source checks as browser tests.
