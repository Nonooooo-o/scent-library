# 私藏香水世界 / Private Scent Library — project guide for Claude

This is the REAL source of the owner's live site (peppy-conkies-530386.netlify.app): a Vite + React SPA. Building it reproduces the live `assets/index-BFpIoEzO.js` and `index-BV_iR_e2.css` byte for byte (verified). `app/` and `next.config.mjs` are leftovers from early iterations and are not part of the build. See also README.md and BUILD.md.

## The owner's goal
The owner finds the current look too flat/blurry and wants a much more striking, cinematic, "very cool" site. Work in whatever direction the owner's message asks (refine the existing immersive entrance, or a bolder redesign), but keep the content truthful: 1,612 real perfumes, 219 brands, the owner's own 1-5 ratings, no invented data. UI is Chinese-first (zh-CN) with English names shown.

## Build (important quirks)
- `npm ci`, then build WITHOUT the first validation step, because the full image set is not in this repo:
  `npx vite build --config vite.spa.config.mjs`  -> output in `dist/client/` (contains index.html, assets/, _headers, _redirects, favicon.svg, images/).
- Do not run plain `npm run build` (its first step validate-world-cutouts needs the full thumbnails) and do not use `next build`.
- `npm run dev` starts the dev server (vite.spa.config.mjs).

## Images
- The full image set (`public/thumbnails/` 319MB, `public/perfumes/` 277MB) is NOT here. Only ~100 sample files are in `public/thumbnails/` so local previews show some real bottles. Everything else must degrade gracefully (typographic/colour fallback), never a broken-image icon.
- Image URLs in the data are absolute paths such as `/thumbnails/p0178_card.webp`, `/thumbnails/p0178_hero.webp`, `/thumbnails/p0178_world.webp` (transparent cutouts). Never rename these paths or add new image files that the owner would have to generate.
- Image quality differs: ~1,280 perfumes have a large hero image (~860-900px); ~330 only have a tiny image (some 91x135px). Never enlarge tiny ones: show them small in a grid with typographic treatment. `data/image-classes.json` classifies images (class D = unsuitable for the immersive scene) and `data/world-cutouts.json` lists transparent cutouts for the 3D-ish entrance.
- `data/collection.json` is the presentation data used by the app (`lib/library-model.mjs`). Do not edit `data/perfumes.json` or ratings unless asked.

## Hosting constraints (Netlify static, strict CSP in public/_headers)
`default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'`. So: bundle all dependencies via npm (three, gsap etc. are fine), self-host fonts, no CDN or external requests, no inline <script>/<style>, no inline style="" attributes (set styles via classes or element.style from JS). Relax the CSP only if strictly needed and say so.

## Delivery (the owner deploys by hand)
The owner's local site folder already contains the real `thumbnails/` folder. They will copy ONLY `dist/client/index.html`, `dist/client/assets/`, `_headers`, `_redirects` (and favicon/images if changed) into that folder, then drag the whole folder into Netlify Drop. So: never tell them to replace their folder with `dist/client/`, and never change image paths. When finished, commit the source changes (not node_modules) and list exactly which built files to copy.

## Working style
Show your work visually when you can: start the dev server, take screenshots (Playwright/Chromium are installed) at desktop and mobile widths, and fix visible problems before reporting. Respect prefers-reduced-motion. Keep it smooth on phones.
