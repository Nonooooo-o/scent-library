import { createContext, useContext } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region lib/navigation.jsx
var Router = createContext({
	navigate: () => {},
	focusId: null,
	draw: () => {}
});
function Arrow({ back = false }) {
	return /* @__PURE__ */ jsx("svg", {
		className: back ? "icon backwards" : "icon",
		viewBox: "0 0 24 24",
		fill: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ jsx("path", {
			d: "M4 12h15m-6-6 6 6-6 6",
			stroke: "currentColor",
			strokeWidth: "1.25"
		})
	});
}
function SearchIcon() {
	return /* @__PURE__ */ jsxs("svg", {
		className: "icon",
		viewBox: "0 0 24 24",
		fill: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ jsx("circle", {
			cx: "10.5",
			cy: "10.5",
			r: "6.5",
			stroke: "currentColor",
			strokeWidth: "1.3"
		}), /* @__PURE__ */ jsx("path", {
			d: "m16 16 5 5",
			stroke: "currentColor",
			strokeWidth: "1.3"
		})]
	});
}
function Link({ href, children, onClick, elementRef, ...props }) {
	const { navigate } = useContext(Router);
	return /* @__PURE__ */ jsx("a", {
		href,
		ref: elementRef,
		...props,
		onClick: (e) => {
			onClick?.(e);
			if (!e.defaultPrevented && e.button === 0 && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.altKey && href.startsWith("/")) {
				e.preventDefault();
				navigate(href, { image: e.currentTarget.querySelector("img") });
			}
		},
		children
	});
}
//#endregion
export { Arrow, Link, Router, SearchIcon };
