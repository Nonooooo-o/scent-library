import {createRoot} from 'react-dom/client';
import '../app/globals.css';
import ArchiveApp from '../components/ArchiveApp.jsx';

createRoot(document.getElementById('root')).render(<ArchiveApp/>);
