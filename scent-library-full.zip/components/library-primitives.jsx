import React, { useContext } from 'react';
import {Router} from '../lib/navigation';
import imageClasses from '../data/image-classes.json';
import worldCutouts from '../data/world-cutouts.json';

// Audit image class (A/B/C/D from the final image audit). Used only to gate
// Object Chamber hero presentation: C/D assets stay small and quiet.
const imageClassFor=p=>imageClasses[p?.id]||(p?.imageVerificationStatus==='verified'?'B':'C');

// Transparent world derivative for the immersive scenes (entrance, Explore,
// Brands, Timeline, 5★ room): /thumbnails/{id}_world.webp with alpha.
// Archive / Search / Object Chamber keep the PRODUCT image (white bg is fine).
// Returns null when no world cutout exists yet, so callers fall back cleanly.
export function worldSrcFor(perfume){
 const id=perfume?.id;
 return (id&&worldCutouts[id])?`/thumbnails/${id}_world.webp`:null;
}

// Responsive derivatives follow the /thumbnails/{id}_{variant}.webp convention
// (thumb 300w, card 600w, medium 1000w, hero 1600w). Records still on the old
// single-asset layout (/thumbnails/{id}.webp) keep a plain single-src <img>.
function srcSetFor(src){
  if(typeof src!=='string')return null;
  const m=/\/thumbnails\/(.+?)_(thumb|card|medium|hero)\.webp$/.exec(src);
  if(!m)return null;
  const base=`/thumbnails/${m[1]}`;
  return `${base}_thumb.webp 300w, ${base}_card.webp 600w, ${base}_medium.webp 1000w, ${base}_hero.webp 1600w`;
}

const DEFAULT_SIZES='(max-width: 640px) 42vw, (max-width: 1279px) 21vw, 220px';

export function PerfumeImage({perfume,eager=false,detail=false,hero=false,world=false,sizes}) {
  const {focusId}=useContext(Router);
  // The Object Chamber is a single-object exhibition room on a dark stage:
  // prefer the transparent world cutout there too when one exists, so the
  // vitrine never reads as a white product card. Falls back to product hero.
  const wsrc=(world||detail)?worldSrcFor(perfume):null; // transparent bottle, no card
  const src=wsrc||(hero&&perfume.imageHero)||perfume.image;
  const srcSet=wsrc?null:srcSetFor(src);
  const imgClass=detail?imageClassFor(perfume):null;
  return <img className="bottle-image" data-perfume-id={perfume.id} data-world-cutout={wsrc?'1':undefined} data-image-class={imgClass||undefined} src={src} srcSet={srcSet||undefined} sizes={srcSet?(sizes||DEFAULT_SIZES):undefined} width={perfume.imageWidth} height={perfume.imageHeight} alt={`${perfume.brand} ${perfume.nameChinese}`} loading={eager?'eager':'lazy'} decoding="async" style={detail&&focusId===perfume.id?{viewTransitionName:'selected-bottle'}:undefined} onError={e=>{e.currentTarget.style.visibility='hidden'}}/>;
}
