import React,{useContext,useEffect,useLayoutEffect,useMemo,useRef,useState} from 'react';
import {Router,Link,Arrow} from '../lib/navigation';
import {PerfumeImage} from './library-primitives';
import {PERFUMES,BY_ID,BRANDS,BRAND_BY_NAME,BRAND_BY_SLUG,FIVE_STAR,DECADES,archiveUrl,randomBottle} from '../lib/library-model.mjs';
import {HERO_IDS,worldPose,clamp,timelineIndex,ENTRY_SLOTS,ENTRY_SLOTS_LITE,ENTRY_SLOTS_MOBILE} from '../lib/world-model.mjs';
import tones from '../data/bottle-tones.json';
import imageClasses from '../data/image-classes.json';
import quarantinedIds from '../data/world-cutouts-quarantined.json';
const QUARANTINED=new Set(quarantinedIds.ids);
const HERO=HERO_IDS.map(id=>BY_ID.get(id));
const TIMES=DECADES.map(decade=>({decade,items:PERFUMES.filter(p=>p.releaseYear&&Math.floor(p.releaseYear/10)*10===decade).sort((a,b)=>a.releaseYear-b.releaseYear||b.personalRating-a.personalRating)}));
const toneFor=p=>tones[p?.id]||'70,76,109';
// World floating composition: D-class placeholders never float (no bottle to
// cut out); backfill from the same sorted list so slot counts stay intact.
// C-class bottles render smaller and never take the hero slot.
const worldClassOf=p=>imageClasses[p?.id]||'B';
const notDWorld=p=>worldClassOf(p)!=='D';
// Bottles whose auto cutout was quarantined (see audit/world_cutouts_quarantine.csv)
// never float in the world; worldPick backfills from the same sorted list so
// slot counts stay intact. Their product images are untouched (Archive/Search).
const worldOk=p=>notDWorld(p)&&!QUARANTINED.has(p?.id);
// Five-star room floats only bottles with a clean world cutout.
const FIVE_OK=FIVE_STAR.filter(worldOk);
const worldScaleFor=p=>{const c=worldClassOf(p);return c==='C'?.7:c==='D'?.55:1;};
function worldPick(list,n,sort){
 const pool=(sort?[...list].sort(sort):[...list]).filter(worldOk);
 return pool.slice(0,n);
}
// Move the first A/B bottle to the hero slot so a low-res cutout never leads.
function frontWorldHero(list){
 const i=list.findIndex(p=>worldClassOf(p)!=='C');
 if(i>0){const [p]=list.splice(i,1);list.unshift(p);}
 return list;
}
// Random draw inside the world only ever reveals a bottle that has a clean
// world cutout (no white product cards on the dark stage).
const randomWorldBottle=(except)=>{let p=randomBottle(except),guard=0;while(!worldOk(p)&&guard++<50)p=randomBottle(except);return p;};
function getMotionProfile(){
 if(typeof window==='undefined')return {lite:false,reduced:false,compact:false};
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches,compact=matchMedia('(max-width: 700px)').matches;
 return {reduced,compact,lite:reduced||compact||!!navigator.connection?.saveData||(navigator.hardwareConcurrency>0&&navigator.hardwareConcurrency<=4)||(navigator.deviceMemory>0&&navigator.deviceMemory<=4)};
}
export function useMotionProfile(){
 const [value,setValue]=useState(getMotionProfile);
 useEffect(()=>{const queries=[matchMedia('(prefers-reduced-motion: reduce)'),matchMedia('(max-width: 700px)')];const update=()=>setValue(getMotionProfile());queries.forEach(q=>q.addEventListener('change',update));navigator.connection?.addEventListener?.('change',update);return()=>{queries.forEach(q=>q.removeEventListener('change',update));navigator.connection?.removeEventListener?.('change',update)}},[]);
 return value;
}

// Native scrolling; only transform/opacity writes in the camera frame. No wheel hijacking.
function useWorldCamera({root,stage,objects,mode,shape,count,clusters,motion,softenHero=1,scalesRef,slotMap,onProgress}){
 const input=useRef({x:0,y:0,drag:0,progress:0}),current=useRef([]),request=useRef(()=>{}),pointer=useRef(null),didDrag=useRef(false);
 const settle=useRef(1); // eases back to 1 after every mode/shape change: slow cinematic reorganization
 const callback=useRef(onProgress);callback.current=onProgress;
 useLayoutEffect(()=>{
  const el=stage.current,container=root.current;if(!el||!container)return;
  settle.current=.28;
  let frame=0,previous=0,width=el.clientWidth,height=el.clientHeight,top=0,distance=1,live=true;
  const stop=()=>{cancelAnimationFrame(frame);frame=0;};
  const tick=now=>{
   frame=0;if(!live||document.hidden)return;
   const dt=Math.min(40,now-(previous||now-16));previous=now;
   settle.current=Math.min(1,settle.current+dt/1600);
   const ease=.32+.68*settle.current;
   const alpha=(motion.reduced?1:1-Math.pow(.82,dt/16))*ease;
   const v=input.current;let moving=false;const damp=mode==='five'?.35:1; // the chamber answers slowly
   for(let i=0;i<objects.current.length;i++){
    const node=objects.current[i];if(!node)continue;
    const target=worldPose(i,{mode:shape,progress:motion.reduced?0:v.progress,drag:motion.reduced?0:v.drag,width,height,compact:motion.compact,lite:motion.lite,count,clusters,slotMap});
    if(shape==='five'&&i===0)target.scale*=softenHero; // C/D heroes stay near native size
    else target.scale*=scalesRef?.current?.[i]??1; // C-class world cutouts stay small and quiet
    if(!motion.lite){target.x+=v.x*Math.max(3,target.z)*.75*damp;target.y+=v.y*Math.max(3,target.z)*.5*damp;}
    if(i>=count)target.opacity=0;
    if(node._layer!==target.layer){node.classList.remove('depth-fg','depth-mg','depth-bg');node.classList.add(target.layer===0?'depth-fg':target.layer===1?'depth-mg':'depth-bg');node._layer=target.layer;}
    if(node._behind!==target.behind){node.classList.toggle('is-behind',target.behind===1);node._behind=target.behind;}
    const c=current.current[i]||(current.current[i]={...target});
    for(const key of ['x','y','scale','angle','opacity','h']){const delta=target[key]-c[key];if(Math.abs(delta)>.002){c[key]+=delta*alpha;moving=true;}else c[key]=target[key];}
    node.style.transform=`translate3d(${c.x.toFixed(2)}px,${c.y.toFixed(2)}px,0) translate(-50%,-50%) rotate(${c.angle.toFixed(2)}deg) scale(${c.scale.toFixed(4)})`;
    node.style.opacity=c.opacity.toFixed(3);node.style.zIndex=String(Math.max(1,target.z));node.style.setProperty('--object-height',c.h.toFixed(1)+'px');
   }
   const p=motion.reduced?0:v.progress;
   el.style.setProperty('--journey',String(p));el.style.setProperty('--type-scale',String(1+p*(motion.lite?.45:2.8)));
   el.style.setProperty('--type-rise',String(-p*150)+'px');
   el.style.setProperty('--type-opacity',String(mode==='entry'?clamp(1-p*2.45):1));
   el.style.setProperty('--pointer-x',String(v.x*3)+'%');el.style.setProperty('--pointer-y',String(v.y*3)+'%');
   if(moving)frame=requestAnimationFrame(tick);
  };
  const kick=()=>{if(!frame&&!document.hidden)frame=requestAnimationFrame(tick)};request.current=kick;
  const scroll=()=>{input.current.progress=clamp((window.scrollY-top)/distance);callback.current(input.current.progress);kick()};
  const measure=()=>{width=el.clientWidth;height=el.clientHeight;top=window.scrollY+container.getBoundingClientRect().top;distance=Math.max(1,container.offsetHeight-height);scroll()};
  const visibility=()=>{el.classList.toggle('world-paused',document.hidden);document.hidden?stop():kick()};
  measure();window.addEventListener('scroll',scroll,{passive:true});window.addEventListener('resize',measure,{passive:true});document.addEventListener('visibilitychange',visibility);
  return()=>{live=false;stop();request.current=()=>{};window.removeEventListener('scroll',scroll);window.removeEventListener('resize',measure);document.removeEventListener('visibilitychange',visibility)};
 },[mode,shape,count,clusters[0],clusters[1],motion.lite,motion.reduced,motion.compact,softenHero,slotMap]);
 const end=e=>{const d=pointer.current;if(d&&e.currentTarget.hasPointerCapture?.(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId);pointer.current=null;stage.current?.classList.remove('world-dragging')};
 return {
  onPointerDown:e=>{didDrag.current=false;if(motion.reduced||e.button!==0||e.target.closest('[data-world-ui]'))return;pointer.current={x:e.clientX,y:e.clientY,drag:input.current.drag};},
  onPointerMove:e=>{
   const d=pointer.current;
   if(d){const dx=e.clientX-d.x,dy=e.clientY-d.y;if(!didDrag.current&&Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)){didDrag.current=true;e.currentTarget.setPointerCapture(e.pointerId);stage.current?.classList.add('world-dragging')}
    if(didDrag.current){input.current.drag=d.drag+dx/e.currentTarget.clientWidth*4;request.current();}return;}
   if(motion.lite||e.pointerType!=='mouse')return;
   const rect=e.currentTarget.getBoundingClientRect();input.current.x=(e.clientX-rect.left)/rect.width-.5;input.current.y=(e.clientY-rect.top)/rect.height-.5;request.current();
  },
  onPointerUp:end,onPointerCancel:end,
  onPointerLeave:()=>{if(!pointer.current){input.current.x=0;input.current.y=0;request.current()}},
  onClickCapture:e=>{if(didDrag.current){e.preventDefault();e.stopPropagation();didDrag.current=false;}}
 };
}
function WorldObject({perfume:p,index,visible,focus,opening,onFocus,onOpen,register,motion,slotMap}){
 const initial=worldPose(index,{compact:motion.compact,slotMap});
 const wscale=worldScaleFor(p); // low-res world cutouts start small, like the camera keeps them
 const depth=initial.layer===0?'depth-fg':initial.layer===1?'depth-mg':'depth-bg';
 return <Link href={`/perfume/${p.id}`} data-world-object="" className={`world-object ${depth} ${initial.behind?'is-behind':''} ${focus===p.id?'is-focused':''} ${opening===p.id?'is-opening':''} ${!visible?'is-dormant':''}`} aria-label={`${p.brand} ${p.nameChinese}，我的评分 ${p.personalRating}/5`} aria-hidden={!visible||undefined} tabIndex={visible?0:-1}
  style={{'--object-height':initial.h+'px','--drift-delay':(-index*1.83)+'s',opacity:initial.opacity,zIndex:Math.max(1,initial.z),transform:`translate3d(${initial.x/14.4}vw,${initial.y/9}svh,0) translate(-50%,-50%) rotate(${initial.angle}deg) scale(${(initial.scale*wscale).toFixed(4)})`}}
  onMouseEnter={()=>onFocus(p.id)} onMouseLeave={()=>onFocus(null)} onFocus={()=>onFocus(p.id)} onBlur={()=>onFocus(null)}
  onClick={e=>{if(e.button===0&&!e.metaKey&&!e.ctrlKey&&!e.shiftKey&&!e.altKey){e.preventDefault();onOpen(p,e.currentTarget)}}}
  elementRef={register}>
  <span className="object-body"><span className="object-drift"><PerfumeImage perfume={p} eager={index<6} world/></span></span>
  <span className="object-discovery"><span>{p.brand}</span><strong>{p.nameChinese}</strong><em>No. {String(p.sourceOrder).padStart(4,'0')}</em><i>走近这瓶 ↗</i></span>
 </Link>;
}
export function WorldEntrance({params=new URLSearchParams()}){
 const {navigate,motion:provided}=useContext(Router);const motion=provided||{lite:false,reduced:false,compact:false};
 const root=useRef(null),stage=useRef(null),objects=useRef([]),openTimer=useRef(null);
 const mode=['brands','time','five'].includes(params.get('space'))?params.get('space'):'entry';
 const brand=BRAND_BY_SLUG.get(params.get('brand'))||BRAND_BY_NAME.get('Amouage');
 const favourite=FIVE_OK.find(p=>p.id===params.get('bottle'))||BY_ID.get('p0849');
 const favouriteClass=imageClasses[favourite.id]||'B';
 const softenHero=(favouriteClass==='C'||favouriteClass==='D')?.7:1; // low-res heroes stay near native size
 const [era,setEra]=useState(0),[deep,setDeep]=useState(false),[preview,setPreview]=useState(null),[focus,setFocus]=useState(null),[opening,setOpening]=useState(null),[drawn,setDrawn]=useState(null);
 const shape=mode==='entry'?(preview||'entry'):mode;
 const previousBrand=BRANDS[(brand.index+BRANDS.length-1)%BRANDS.length],nextBrand=BRANDS[(brand.index+1)%BRANDS.length];
 const time=TIMES[era];
 const items=useMemo(()=>{
  // Composition pass (Phase 7): ~25-40% fewer prominent bottles per scene so
  // the rooms read as a walkable collection, not a pile. Slot counts stay
  // intact (dormant slots keep SSR/DOM counts stable); only activeCount shrinks.
  if(mode==='brands')return frontWorldHero([...worldPick(brand.items,motion.compact?4:6,(a,b)=>b.personalRating-a.personalRating),...worldPick(previousBrand.items,motion.compact?1:2,(a,b)=>b.personalRating-a.personalRating),...worldPick(nextBrand.items,motion.compact?1:2,(a,b)=>b.personalRating-a.personalRating)]);
  if(mode==='time')return frontWorldHero(worldPick(time.items,motion.compact?3:6));
  if(mode==='five'){const index=FIVE_OK.indexOf(favourite);return [favourite,FIVE_OK[(index+FIVE_OK.length-1)%FIVE_OK.length],FIVE_OK[(index+1)%FIVE_OK.length]];}
  return HERO.slice(0,motion.compact?8:motion.lite?13:19);
 },[mode,brand,time,favourite,motion.compact,motion.lite]);
 // Full slot list (with HERO backfill, mirroring the render loop) so the
 // per-slot world scale factors line up with the objects the camera moves.
 const slots=motion.compact?12:motion.lite?18:28;
 const slotItems=useMemo(()=>Array.from({length:slots},(_,i)=>items[i]||HERO[i]),[items,slots]);
 const slotScales=useMemo(()=>slotItems.map(worldScaleFor),[slotItems]);
 const scalesRef=useRef();scalesRef.current=slotScales;
 const activeCount=shape==='five'?3:shape==='time'?Math.min(motion.compact?3:6,items.length):shape==='brands'?Math.min(motion.compact?6:10,items.length):items.length;
 const clusters=mode==='brands'?[Math.min(brand.items.length,motion.compact?4:6),Math.min(previousBrand.items.length,motion.compact?1:2)]:[motion.compact?4:6,motion.compact?1:2];
 // The grand hall thins its field via a curated slot map: the visible exhibits
 // spread across the full near/mid/far FIELD instead of crowding the near slots.
 const slotMap=shape==='entry'?(motion.compact?ENTRY_SLOTS_MOBILE:motion.lite?ENTRY_SLOTS_LITE:ENTRY_SLOTS):undefined;
 const camera=useWorldCamera({root,stage,objects,mode,shape,count:activeCount,clusters,motion,softenHero,scalesRef,slotMap,onProgress:p=>{setDeep(p>.31);if(mode==='time'&&!motion.reduced)setEra(timelineIndex(p,TIMES.length));}});
 useEffect(()=>{setPreview(null);setFocus(null);setOpening(null);clearTimeout(openTimer.current);},[mode]);
 useEffect(()=>()=>clearTimeout(openTimer.current),[]);
 useEffect(()=>setFocus(null),[items]);
 const enter=space=>{setPreview(null);navigate(space==='entry'?'/':'/?space='+space,{transition:false});};
 const update=values=>{const next=new URLSearchParams(params);Object.entries(values).forEach(([k,v])=>next.set(k,v));navigate('/?'+next,{replace:true,keepScroll:true,transition:false})};
 const goDeeper=()=>window.scrollTo({top:root.current.offsetTop+(root.current.offsetHeight-stage.current.clientHeight)*.56,behavior:motion.reduced?'instant':'smooth'});
 const changeEra=delta=>{const next=clamp(era+delta,0,TIMES.length-1);setEra(next);if(!motion.reduced)window.scrollTo({top:root.current.offsetTop+(root.current.offsetHeight-stage.current.clientHeight)*(next+.1)/TIMES.length,behavior:'instant'})};
 const changeFavourite=delta=>update({bottle:FIVE_OK[(FIVE_OK.indexOf(favourite)+delta+FIVE_OK.length)%FIVE_OK.length].id});
 const openObject=(p,element)=>{if(opening)return;setOpening(p.id);const image=element.querySelector('img');openTimer.current=setTimeout(()=>navigate('/perfume/'+p.id,{image:image?.dataset.perfumeId===p.id?image:null}),motion.reduced?0:230)};
 const doorsVisible=mode!=='entry'||deep||motion.reduced;
 return <div ref={root} className={`world-journey ${motion.lite?'world-lite':''} ${motion.reduced?'world-reduced':''}`} data-mode={mode}>
  <section ref={stage} {...camera} className={`world-canvas ${focus?'has-object-focus':''} ${doorsVisible?'paths-visible':''}`} data-mode={mode} data-shape={shape} style={{'--chamber-tone':toneFor(mode==='five'?favourite:items[0])}} aria-label="私藏香水世界，滚动深入，拖动漫游">
   <div className="world-atmosphere" aria-hidden="true"><div className="ink-wash"/><div className="light-fold light-fold-a"/><div className="light-fold light-fold-b"/><div className="chamber-light"/><div className="exhibit-rails" aria-hidden="true"><i/><i/><i/></div><div className="case-verticals" aria-hidden="true"/><div className="world-grain"/></div>
   <Link className="world-index-link" href="/archive" data-world-ui="">馆藏索引 <span>↗</span></Link>
   {mode!=='entry'&&<button className="world-return" data-world-ui="" onClick={()=>enter('entry')}><Arrow back/><span>回到入口</span></button>}
   <div className="world-field" aria-label="漂浮的真实馆藏">
    {slotItems.map((p,i)=><WorldObject key={i} perfume={p} index={i} visible={i<activeCount} focus={focus} opening={opening} onFocus={setFocus} onOpen={openObject} register={node=>{objects.current[i]=node}} motion={motion} slotMap={slotMap}/>)}
   </div>
   {mode==='entry'?<>
    <div className="collection-monument" aria-hidden="true"><span>1600+</span><span className="monument-echo" aria-hidden="true">1600+</span></div>
    <div className="world-authorship"><span className="private-word">PRIVATE</span><h1>私藏香水世界</h1><span className="scent-library-word">SCENT LIBRARY</span></div>
    <p className="inner-whisper">这些气味，<br/>都曾经过我的生活。</p>
    <p className="world-signature">一个人的 1600+ 瓶。<br/><span>还有，尚未抵达的记忆。</span></p>
   </>:mode==='brands'?<>
    <div className="world-monument brand-monument" aria-hidden="true" style={{'--brand-size':Math.min(17,105/(brand.english||brand.name).length)+'vw'}}>{brand.english||brand.name}</div>
    <div className="room-intimacy" aria-live="polite"><h1>品牌的引力</h1><p>{brand.name} · {brand.items.length} 件私藏</p></div>
    <div className="neighbour-brands" data-world-ui=""><button onClick={()=>update({brand:previousBrand.slug})}>{previousBrand.english||previousBrand.name}</button><button onClick={()=>update({brand:nextBrand.slug})}>{nextBrand.english||nextBrand.name}</button></div>
    <div className="brand-space-controls world-controls" data-world-ui=""><label>换一座书架<select aria-label="选择收藏中的品牌" value={brand.slug} onChange={e=>update({brand:e.target.value})}>{BRANDS.map(b=><option key={b.slug} value={b.slug}>{b.english||b.name} · {b.items.length}</option>)}</select></label><Link href={'/brand/'+brand.slug}>走进 {brand.name}<Arrow/></Link></div>
   </>:mode==='time'?<>
    <div key={time.decade} className="world-monument time-monument" aria-hidden="true">{time.items[0].releaseYear}</div>
    <div className="time-echo" key={'echo'+time.decade} aria-hidden="true">{TIMES[Math.min(era+1,TIMES.length-1)].items[0].releaseYear}</div>
    <div className="room-intimacy" aria-live="polite"><h1>气味的时间</h1><p>{time.decade}—{time.decade+9} · {time.items.length} 件馆藏</p></div>
    <div className="time-space-controls world-controls" data-world-ui=""><div><button onClick={()=>changeEra(-1)} disabled={era===0} aria-label="更早的年代"><Arrow back/></button><span>{motion.reduced?'选择年代':'继续滚动，穿过时间'}</span><button onClick={()=>changeEra(1)} disabled={era===TIMES.length-1} aria-label="更近的年代"><Arrow/></button></div><Link href={archiveUrl({decade:time.decade,sort:'year-asc'})}>打开这一年代的馆藏<Arrow/></Link></div>
    <div className="time-rail" aria-hidden="true"><span className="rail-spine"/>{TIMES.map((t,i)=><span key={t.decade} className={'tick'+(i===era?' is-now':'')}><i/><span>{t.decade}s</span></span>)}</div>
   </>:<>
    <div className="world-monument five-monument" aria-hidden="true">5<span>/5</span></div>
    <div className="room-intimacy" aria-live="polite"><h1>留在最里面的气味</h1><p>127 件，我的最高评分。</p></div>
    <div className="favourite-name" aria-live="polite"><span>{favourite.brand}</span><h2>{favourite.nameChinese}</h2><em>私藏五星 · {FIVE_OK.indexOf(favourite)+1} / {FIVE_OK.length}</em></div>
    <div className="five-space-controls world-controls" data-world-ui=""><div><button onClick={()=>changeFavourite(-1)} aria-label="上一件五星藏品"><Arrow back/></button><span>再遇见一瓶</span><button onClick={()=>changeFavourite(1)} aria-label="下一件五星藏品"><Arrow/></button></div><Link href="/five-star">我的全部五星<Arrow/></Link></div>
   </>}
   <div className="world-destinations" data-world-ui="" aria-label="探索目的地" aria-hidden={!doorsVisible||undefined} inert={!doorsVisible}>
    {[['brands','Brands','品牌的引力'],['time','Timeline','气味的时间'],['five','5★','留在最里面']].map(([id,en,zh])=><button key={id} className={'destination destination-'+id} aria-pressed={mode===id} onMouseEnter={()=>mode==='entry'&&!motion.reduced&&setPreview(id)} onMouseLeave={()=>setPreview(null)} onFocus={()=>mode==='entry'&&!motion.reduced&&setPreview(id)} onBlur={()=>setPreview(null)} onClick={()=>enter(id)}><span>{en}</span><small>{zh}</small><i aria-hidden="true">↗</i></button>)}
   </div>
   <div className="world-floor" data-world-ui=""><button className="secret-draw" onClick={()=>setDrawn(randomWorldBottle())}><span aria-hidden="true">↝</span><span>闭上眼，抽一瓶</span></button>{mode==='entry'&&<button className="enter-deeper" onClick={goDeeper} hidden={motion.reduced||deep}><span>往里走</span><span className="falling-line" aria-hidden="true">↓</span></button>}<span className="touch-invitation">{motion.reduced?'任选一瓶，进入收藏':'拖动漫游 · 点选瓶身'}</span></div>
   <p className="world-accessible-description">1,612 款真实香水，219 个品牌。{mode==='entry'?'滚动或选择“往里走”，发现品牌、时间和五星空间。':''}</p>
  </section>
  {drawn&&<RandomReveal perfume={drawn} onClose={()=>setDrawn(null)} onDraw={()=>setDrawn(randomWorldBottle(drawn.id))} onOpen={image=>navigate('/perfume/'+drawn.id,{image})}/>}
 </div>;
}
function RandomReveal({perfume,onClose,onDraw,onOpen}){
 const ref=useRef(null);
 useEffect(()=>{ref.current?.showModal();return()=>ref.current?.close()},[]);
 return <dialog ref={ref} className="world-random" onCancel={e=>{e.preventDefault();onClose()}} style={{'--chamber-tone':toneFor(perfume)}}><button className="random-close" onClick={onClose} aria-label="回到收藏世界">×</button><div className="drawn-object" key={perfume.id}><span>从我的 1,612 瓶之中</span><button className="drawn-bottle" aria-label={'走近'+perfume.nameChinese} onClick={()=>onOpen(ref.current.querySelector('img'))}><PerfumeImage perfume={perfume} eager world hero/></button><span>{perfume.brand}</span><h2>{perfume.nameChinese}</h2><button onClick={()=>onOpen(ref.current.querySelector('img'))}>走近这瓶 <Arrow/></button></div><button className="draw-again" onClick={onDraw}>再抽一瓶 ↝</button></dialog>;
}
